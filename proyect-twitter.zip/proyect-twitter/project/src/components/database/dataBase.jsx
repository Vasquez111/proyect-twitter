export let usuarios = [
    {
        user: 'admin',
        contrasena: 1234
    },
    {
        user: 'jack',
        contrasena: 1234
    }
]
export function saludar(){
    
}