import  {useState}  from 'react'
import { usuarios } from '../../database/dataBase'
const Login = () => {

    usuarios.some(()=>{})

    const [getUsuario, setUsuario] = useState()
    const [getContrasena, setContrasena] = useState()
    function validarIniciosesion() {
        if (getUsuario == "Jack" && getContrasena == "1234"){
            console.log("Inicio de sesion correcta");
        } else {
            console.log("Error de credeciales");
        }
    }
    function buscarUsuario(){
        return usuarios.some(usuario => usuario.user == getUsuario)
    }
        return(
        <form action="">
            <section>
                <input onChange={(e)=> setUsuario(e.target.value)} placeholder="Usuarios" type="text" />
                <input onChange={(e)=> setContrasena(e.target.value)} placeholder="Contrasena" type="text" />
            </section>
            <button onClick={validarIniciosesion} type="button">Iniciar Sesión</button>
            
        </form>

        
    )
}

export default Login