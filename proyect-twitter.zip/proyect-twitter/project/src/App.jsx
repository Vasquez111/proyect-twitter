import Login from "./components/layouts/auth/Login"

function App() {
  

  return (
    <>
      <Login />
    </>
  )
}

export default App
