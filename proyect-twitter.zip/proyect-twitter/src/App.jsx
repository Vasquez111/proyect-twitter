import Inicio from "./assets/Inicio"

function App() {
  
  return (
    <>
      <Inicio />
    </>
  )
}

export default App
