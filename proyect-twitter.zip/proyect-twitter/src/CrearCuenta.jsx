import './CrearCuenta.css'

function CrearCuenta () {
    return (
        <div>
            <button>Crear cuenta</button>
            <h1>Al registrarte, aceptas los Términos de servicio y la Política de privacidad, incluida la política de Uso de Cookies.</h1>
        </div>
    );
}

export { CrearCuenta }