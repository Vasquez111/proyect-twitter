import './IniciarSesion.css'

function IniciarSesion () {
    return (
        <div>
            <h2>¿Ya tienes tu cuenta?</h2>
            <button>Iniciar sesión</button>
        </div>
    )
}

export { IniciarSesion }