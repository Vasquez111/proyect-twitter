import { CrearCuenta } from "../CrearCuenta"
import { IniciarSesion } from "../IniciarSesion"
import { Registro } from "../Registro"
import React from "react"

const Inicio = () => {
    return(
        <form action="">
            
            <img src="public/img/Twitter.png" alt="" width="300px" />

            <h3>Lo que está pasando ahora</h3>
            <div >Únete Hoy</div>

            <Registro />

            <div>o</div>

            <CrearCuenta />

            <IniciarSesion />

            
        </form>


    )

}

export default Inicio