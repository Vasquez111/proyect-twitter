
function Registro () {
    return (
        <div >
        <button>Registrate con Google</button>
        <button>Registrate con Apple</button>
        </div>
    );
}

export { Registro }